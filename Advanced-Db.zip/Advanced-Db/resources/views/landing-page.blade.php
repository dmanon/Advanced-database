<!DOCTYPE html>
<html>
    <head>
        <title>POS System</title>
    </head>
    <body>
        <h1>Welcome to the POS System</h1>
        <div>
            <a href="/receive-items"><button>Receive Items</button></a>
            <a href="/sell"><button>Sell Items</button></a>
            <a href="/sale-history"><button>Sale History</button></a>
            <a href="/purchase-history"><button>Purchase History</button></a>
            <a href="/inventory"><button>Inventory</button></a>
        </div>
    </body>
</html>
