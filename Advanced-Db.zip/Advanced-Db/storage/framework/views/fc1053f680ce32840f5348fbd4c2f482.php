<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <style>
        table{
            border-collapse: collapse;
        }
        tr, td,th{
            border: 1px solid black;
        }
    </style>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <header>
        <!-- Header content here -->
    </header>

    <nav>
        <!-- Navigation menu here -->
    </nav>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <!-- Footer content here -->
    </footer>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Advanced_db\Advanced-Db\resources\views/layouts/app.blade.php ENDPATH**/ ?>