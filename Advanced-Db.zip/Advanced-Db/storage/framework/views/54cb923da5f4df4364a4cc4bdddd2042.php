
<?php $__env->startSection('content'); ?>
    <h1>Purchase History</h1>

    <table class="table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Item</th>
                <th>Quantity</th>
                <th>Cost</th>
                <th>Total Cost</th>
                <th>Sell Price</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($purchase->created_at->format('Y-m-d')); ?></td>
                    <td><?php echo e($purchase->name); ?></td>
                    <td><?php echo e($purchase->quantity); ?></td>
                    <td><?php echo e($purchase->cost); ?></td>
                    <td><?php echo e($purchase->cost * $purchase->quantity); ?></td>
                    <td><?php echo e($purchase->sell_price); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <button> <a href="/"> Home</a></button>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Advanced_db\Advanced-Db\resources\views/purchase-history.blade.php ENDPATH**/ ?>