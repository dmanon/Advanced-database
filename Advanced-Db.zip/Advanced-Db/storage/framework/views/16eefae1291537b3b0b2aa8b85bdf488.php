<!DOCTYPE html>
<html>
    <head>
        <title>Receive Items</title>
    </head>
    <body>
        <h1>Receive Items</h1>
        <?php if(session('success')): ?>
            <div style="color: green;"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <form method="post" action="/receive-items">
            <?php echo csrf_field(); ?>
            <div>
                <label for="name">Name:</label>
                <input value="<?php echo e(old('name')); ?>" type="text" id="name" name="name" required>
            </div>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color: red;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div>
                <label for="quantity">Quantity:</label>
                <input value="<?php echo e(old('quantity')); ?>" type="number" id="quantity" name="quantity" required min="1">
            </div>
            <div>
                <label for="cost">Cost:</label>
                <input type="number" id="cost" name="cost" required min="0" step="0.01">
            </div>
            <div>
                <label for="sell_price">Sell Price:</label>
                <input type="number" id="sell_price" name="sell_price" required min="0" step="0.01">
            </div>

            <button type="submit">Receive Item</button>
            <button> <a href="/"> Home</a></button>
        </form>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Advanced_db\Advanced-Db\resources\views/receive-items.blade.php ENDPATH**/ ?>